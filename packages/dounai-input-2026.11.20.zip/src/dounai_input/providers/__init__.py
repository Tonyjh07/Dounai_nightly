"""Provider adapters and discovery."""
