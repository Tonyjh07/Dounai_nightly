/**
 * 上游 HTTP 适配器。
 *
 * 三个模块各自独立，任何一个不可用都不得影响其他两个（见 docs/architecture.md §6）。
 * 因此每个适配器只抛自己的错误类型，由编排层决定降级表现。
 *
 * 传输层见 `transport.ts`：生产环境经主进程代理，开发环境经 Vite 代理，
 * 二者都不受浏览器跨域限制（原因见 docs/cors-and-proxy.md）。
 */

import {
  type InputDegradedInfo,
  type LLMPart,
  type InputEvent,
  type LLMEvent,
  type MetaFrame,
  type ModelEntry,
  type OutputEvent,
  type RouteFrame,
  type UpstreamError,
  type CitationFrame,
  type WarningFrame,
  ContractError,
  parseCitations,
  parseInputDegraded,
  parseInputEvent,
  parseLLMEvent,
  parseMeta,
  parseModels,
  parseOutputEvent,
  parseRoute,
  parseUpstreamError,
  parseWarning,
} from "../contracts/index.js";
import { type HttpRequest, type HttpResponse, TransportError, request, requestStream } from "./transport.js";
import { buildMultipart, guessExtension } from "./multipart.js";

export class UpstreamUnavailableError extends Error {
  readonly module: string;
  constructor(module: string, detail: string) {
    super(`${module} 不可用：${detail}`);
    this.name = "UpstreamUnavailableError";
    this.module = module;
  }
}

export class UpstreamRejectedError extends Error {
  readonly module: string;
  readonly upstream: UpstreamError;
  constructor(module: string, upstream: UpstreamError) {
    super(`${module} 拒绝了请求：${upstream.code}`);
    this.name = "UpstreamRejectedError";
    this.module = module;
    this.upstream = upstream;
  }
}

export class TimeoutError extends Error {
  readonly module: string;
  readonly stage: string;
  constructor(module: string, stage: string, ms: number) {
    super(`${module} 在 ${stage} 阶段超时（${ms}ms）`);
    this.name = "TimeoutError";
    this.module = module;
    this.stage = stage;
  }
}

export interface Endpoints {
  input: string;
  llm: string;
  output: string;
}

export const DEFAULT_ENDPOINTS: Endpoints = {
  input: "http://127.0.0.1:8101",
  llm: "http://127.0.0.1:8102",
  output: "http://127.0.0.1:8103",
};

export const TIMEOUTS = {
  inputText: 15_000,
  inputMedia: 60_000,
  llmFirstToken: 45_000,
  llmTotal: 120_000,
  outputSynthesis: 90_000,
  probe: 3_000,
} as const;

/** 本地类型守卫：契约解析在 contracts 里，这里只用于适配器内部的宽松取值。 */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * 健康探针的契约 major 版本校验。
 *
 * 没有版本字段时保持旧行为（只看 HTTP 状态）；有版本但 major 不匹配时
 * 判为不可用，避免上游 breaking change 被静默当成正常。
 */
function contractMajorOk(raw: unknown, expected: number): boolean {
  if (!isRecord(raw)) return true;
  const version = raw.contract_version;
  if (typeof version !== "string") return true;
  const major = Number.parseInt(version.split(".")[0] ?? "", 10);
  return !Number.isFinite(major) || major === expected;
}

/** 把相对 audio_ref 拼成可播放的绝对地址。 */
export function resolveAudioUrl(outputBase: string, audioRef: string | null): string | null {
  if (!audioRef) return null;
  if (/^https?:\/\//i.test(audioRef)) return audioRef;
  const base = outputBase.replace(/\/+$/, "");
  const path = audioRef.startsWith("/") ? audioRef : `/${audioRef}`;
  return `${base}${path}`;
}

async function readJson(response: HttpResponse): Promise<unknown> {
  const text = response.body;
  if (!text) return null;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new ContractError("upstream", "body", "响应不是合法 JSON");
  }
}

/** 把传输层错误翻译成上游错误，保留超时语义。 */
function toUpstreamError(module: string, stage: string, error: unknown): Error {
  if (error instanceof TimeoutError) return error;
  if (error instanceof TransportError) {
    if (error.kind === "timeout") {
      return new TimeoutError(module, stage, 0);
    }
    return new UpstreamUnavailableError(module, error.message);
  }
  if (error instanceof Error) return new UpstreamUnavailableError(module, error.message);
  return new UpstreamUnavailableError(module, String(error));
}

/* ------------------------------------------------------------------ */
/* input                                                               */
/* ------------------------------------------------------------------ */

export interface SubmitTextResult {
  event: InputEvent;
  degraded: InputDegradedInfo;
}

export class InputAdapter {
  constructor(private readonly base: string) {}

  async probe(): Promise<boolean> {
    try {
      const res = await request({
        url: `${this.base}/healthz`,
        method: "GET",
        timeoutMs: TIMEOUTS.probe,
      });
      if (res.status < 200 || res.status >= 400) return false;
      try {
        return contractMajorOk(await readJson(res), 1);
      } catch {
        return true;
      }
    } catch {
      return false;
    }
  }

  async submitText(text: string, sessionId?: string): Promise<SubmitTextResult> {
    const body = JSON.stringify({
      text,
      ...(sessionId ? { session_id: sessionId } : {}),
      source: "dounai-desktop",
    });

    let response: HttpResponse;
    try {
      response = await request({
        url: `${this.base}/v1/inputs/text`,
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body,
        timeoutMs: TIMEOUTS.inputText,
      });
    } catch (error) {
      throw toUpstreamError("input", "submitText", error);
    }

    return this.finish(response);
  }

  /**
   * 图像输入。
   *
   * 输入层用 multipart + 魔数双重校验，因此必须带真实文件名与 MIME；
   * 单文件上限 15MB，超限由上游返回 413（这里不预检，避免重复实现上游规则）。
   */
  async submitImage(
    image: { bytes: Uint8Array; filename?: string; mime?: string },
    sessionId?: string,
  ): Promise<SubmitTextResult> {
    const mime = image.mime ?? "image/png";
    const filename = image.filename ?? `paste.${guessExtension("", mime)}`;
    return this.submitFile("image", { bytes: image.bytes, filename, mime }, sessionId, {});
  }

  /**
   * 语音输入。
   *
   * `language` 是可选 BCP-47（如 `zh`、`en-US`）；上游会据此选择 ASR 语言。
   * 转写失败时上游仍返回 201，但 `asr_text` 为空且响应头 `X-Dounai-Degraded: true`
   * —— 这就是「语音没转写成功」的唯一可信信号，必须由调用方读取。
   */
  async submitAudio(
    audio: { bytes: Uint8Array; filename?: string; mime?: string; language?: string },
    sessionId?: string,
  ): Promise<SubmitTextResult> {
    const mime = audio.mime ?? "audio/webm";
    const filename = audio.filename ?? `voice.${guessExtension("", mime)}`;
    return this.submitFile(
      "audio",
      { bytes: audio.bytes, filename, mime },
      sessionId,
      audio.language ? { language: audio.language } : {},
    );
  }

  private async submitFile(
    kind: "image" | "audio",
    file: { bytes: Uint8Array; filename: string; mime: string },
    sessionId: string | undefined,
    extraFields: Record<string, string | undefined>,
  ): Promise<SubmitTextResult> {
    const form = buildMultipart(
      { field: "file", filename: file.filename, mime: file.mime, bytes: file.bytes },
      { session_id: sessionId, source: "dounai-desktop", ...extraFields },
    );

    let response: HttpResponse;
    try {
      response = await request({
        url: `${this.base}/v1/inputs/${kind}`,
        method: "POST",
        headers: { "Content-Type": form.contentType },
        bodyBytes: form.bytes,
        timeoutMs: TIMEOUTS.inputMedia,
      });
    } catch (error) {
      throw toUpstreamError("input", `submit${kind === "image" ? "Image" : "Audio"}`, error);
    }

    return this.finish(response);
  }

  private async finish(response: HttpResponse): Promise<SubmitTextResult> {
    const raw = await readJson(response);
    if (response.status >= 400) {
      throw new UpstreamRejectedError("input", parseUpstreamError(raw));
    }
    return {
      event: parseInputEvent(raw),
      degraded: parseInputDegraded(response.headers),
    };
  }
}

/* ------------------------------------------------------------------ */
/* OmniNexus (SSE)                                                     */
/* ------------------------------------------------------------------ */

export interface TurnCallbacks {
  onMeta?(meta: MetaFrame): void;
  onRoute?(route: RouteFrame): void;
  onDelta?(event: LLMEvent): void;
  onCitations?(citations: CitationFrame): void;
  onWarning?(warning: WarningFrame): void;
  onFinal?(event: LLMEvent): void;
}

export interface TurnRequest {
  eventId: string;
  /**
   * 内容分区（D-02）。
   *
   * 不再用单个 `text`：图像必须走独立分区并以 data URI 内联，
   * 否则模型层只会收到一段它无法理解的回环 URL 字符串。
   */
  parts: LLMPart[];
  sessionId?: string;
  model?: string;
  /**
   * 每轮使用的提示词配置 ID（结构图「提示词操作：预留更换接口供 UI 调用」）。
   *
   * 用 model 层支持的**每轮覆盖**语义（`metadata.prompt_profile`），
   * 而不是先建会话再切提示词——后者需要组装层维护会话生命周期，
   * 会让「换提示词」这种轻量操作牵动状态管理。
   */
  promptProfile?: string;
  /**
   * 本轮是否启用联网搜索。
   *
   * 悬浮窗**没有**自己的搜索开关：不传时由 `runTurn` 读取模型层的
   * 会话设置（Web 页「联网搜索」开关）并原样透传，实现跟随。
   */
  webSearch?: boolean;
}

/** 提示词配置（模型层 `/v1/prompts/profiles` 的返回项）。 */
export interface PromptProfile {
  id: string;
  name: string;
  description: string;
  builtin: boolean;
  activeVersion: number;
}

export class LLMAdapter {
  constructor(private readonly base: string) {}

  async probe(): Promise<boolean> {
    try {
      const res = await request({
        url: `${this.base}/v1/healthz`,
        method: "GET",
        timeoutMs: TIMEOUTS.probe,
      });
      if (res.status < 200 || res.status >= 400) return false;
      try {
        return contractMajorOk(await readJson(res), 1);
      } catch {
        return true;
      }
    } catch {
      return false;
    }
  }

  /** 读取模型清单（含能力与可用性）。 */
  async listModels(): Promise<ModelEntry[]> {
    try {
      const res = await request({
        url: `${this.base}/v1/models`,
        method: "GET",
        timeoutMs: TIMEOUTS.probe,
      });
      if (res.status < 200 || res.status >= 400) {
        throw new UpstreamUnavailableError("omninexus", `HTTP ${res.status}`);
      }
      const raw = JSON.parse(res.body) as unknown;
      return parseModels(raw);
    } catch (error) {
      throw toUpstreamError("omninexus", "listModels", error);
    }
  }

  /**
   * 列出可用提示词配置。
   *
   * 失败时返回空数组而不是抛错：提示词选择是**增强功能**，
   * 拿不到列表不应该让整个对话不可用（用户仍可用默认配置聊天）。
   */
  async listPromptProfiles(): Promise<PromptProfile[]> {
    try {
      const res = await request({
        url: `${this.base}/v1/prompts/profiles`,
        method: "GET",
        timeoutMs: TIMEOUTS.probe,
      });
      if (res.status >= 400) return [];
      const raw = await readJson(res);
      const list = isRecord(raw) && Array.isArray(raw.profiles) ? raw.profiles : [];
      return list.filter(isRecord).map((item) => ({
        id: String(item.id ?? ""),
        name: String(item.name ?? item.id ?? ""),
        description: String(item.description ?? ""),
        builtin: Boolean(item.builtin),
        activeVersion: Number(item.active_version ?? 0),
      })).filter((item) => item.id.length > 0);
    } catch {
      return [];
    }
  }

  /**
   * 读取模型层的会话级搜索开关。
   *
   * 悬浮窗不维护独立的搜索开关：用户在 Web 页把某个会话的「联网搜索」
   * 打开/关闭后，下一轮就按这个值发 `metadata.web_search`。
   *
   * 读取失败（旧版模型层没有该端点、会话尚未创建）时返回 undefined，
   * 让模型层继续用会话默认值——绝不能因为一次探测失败就把搜索强行关掉。
   */
  private async sessionWebSearch(sessionId?: string): Promise<boolean | undefined> {
    if (!sessionId) return undefined;
    try {
      const res = await request({
        url: `${this.base}/v1/sessions/${encodeURIComponent(sessionId)}/settings`,
        method: "GET",
        timeoutMs: TIMEOUTS.probe,
      });
      if (res.status < 200 || res.status >= 400) return undefined;
      const raw = await readJson(res);
      return isRecord(raw) && typeof raw.web_search === "boolean" ? raw.web_search : undefined;
    } catch {
      return undefined;
    }
  }

  /**
   * 跑一个完整回合。返回 final 事件；若上游在产生文本前失败则抛错。
   *
   * 注意：这里**不**在首 token 处返回，而是等到 final —— 因为 output 需要完整文本。
   * 流式体验由 onDelta 回调即时推给 UI，二者互不阻塞。
   */
  async runTurn(
    turn: TurnRequest,
    callbacks: TurnCallbacks,
    signal?: AbortSignal,
  ): Promise<LLMEvent> {
    // 搜索开关跟随模型层会话设置；显式传入时以调用方为准。
    const webSearch = turn.webSearch ?? (await this.sessionWebSearch(turn.sessionId));
    const body = JSON.stringify({
      event_id: turn.eventId,
      // D-01：session_id 是模型层 InboundEvent 的**顶层字段**。
      // 放进 metadata 会被当成普通装饰键忽略，模型层随即静默新建会话——
      // 表现为助手"失忆"，且完全没有报错。
      ...(turn.sessionId ? { session_id: turn.sessionId } : {}),
      parts: turn.parts,
      metadata: {
        ...(turn.model ? { model: turn.model } : {}),
        // 每轮覆盖提示词配置；不传则沿用模型层默认
        ...(turn.promptProfile ? { prompt_profile: turn.promptProfile } : {}),
        // 不传时模型层按会话设置决定，这里只透传读到的值
        ...(webSearch !== undefined ? { web_search: webSearch } : {}),
      },
    });

    const httpRequest: HttpRequest = {
      url: `${this.base}/v1/events`,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "text/event-stream",
      },
      body,
      timeoutMs: TIMEOUTS.llmTotal,
      signal,
    };

    const collector = createCollector(callbacks);

    try {
      await requestStream(httpRequest, (chunk) => collector.feed(chunk));
    } catch (error) {
      throw toUpstreamError("omninexus", "stream", error);
    }

    return collector.finish();
  }
}

/**
 * SSE 帧收集器。
 *
 * 逐帧 JSON.parse，单帧损坏只跳过并计数，不让整轮失败——
 * 上游已产生的文本不能因一帧坏掉而丢弃。
 */
function createCollector(callbacks: TurnCallbacks) {
  let buffer = "";
  let finalEvent: LLMEvent | null = null;
  let failure: UpstreamError | null = null;
  let sawWarning = false;
  let badFrames = 0;
  /** 已收到终止帧（final / error）：读取方可立即停止，无需等待 socket EOF */
  let terminated = false;

  function dispatch(rawFrame: string): void {
    let name = "";
    const dataLines: string[] = [];

    for (const line of rawFrame.split(/\r?\n/)) {
      if (line.startsWith(":")) continue; // keep-alive 注释
      if (line.startsWith("event:")) name = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
    }
    if (dataLines.length === 0) return;

    let payload: unknown;
    try {
      payload = JSON.parse(dataLines.join("\n")) as unknown;
    } catch {
      badFrames += 1;
      return;
    }

    try {
      switch (name) {
        case "meta":
          callbacks.onMeta?.(parseMeta(payload));
          break;
        case "route":
          callbacks.onRoute?.(parseRoute(payload));
          break;
        case "delta":
          callbacks.onDelta?.(parseLLMEvent(payload, true));
          break;
        case "citations":
          callbacks.onCitations?.(parseCitations(payload));
          break;
        case "warning":
          callbacks.onWarning?.(parseWarning(payload));
          sawWarning = true;
          break;
        case "error":
          failure = parseUpstreamError(payload);
          terminated = true;
          break;
        case "final": {
          const event = parseLLMEvent(payload, false);
          finalEvent = event;
          terminated = true;
          callbacks.onFinal?.(event);
          break;
        }
        default:
          break;
      }
    } catch (error) {
      // 契约字段缺失：记为坏帧，不中断整轮
      if (error instanceof ContractError) badFrames += 1;
      else throw error;
    }
  }

  return {
    /** 返回 true 表示已收到终止帧，调用方应停止读取。 */
    feed(chunk: string): boolean {
      buffer += chunk;
      for (;;) {
        const boundary = findBoundary(buffer);
        if (boundary === -1) break;
        const rawFrame = buffer.slice(0, boundary.index);
        buffer = buffer.slice(boundary.index + boundary.length);
        dispatch(rawFrame);
        if (terminated) return true;
      }
      return terminated;
    },
    finish(): LLMEvent {
      // 末尾可能没有空行分隔，兜底再派发一次
      if (buffer.trim().length > 0) {
        dispatch(buffer);
        buffer = "";
      }
      if (failure) throw new UpstreamRejectedError("omninexus", failure);
      if (!finalEvent) {
        throw new UpstreamUnavailableError(
          "omninexus",
          sawWarning ? "流在产生 final 前中断" : "流结束但未收到 final",
        );
      }
      if (badFrames > 0 && finalEvent.content.length === 0) {
        throw new UpstreamUnavailableError("omninexus", `全部 ${badFrames} 帧均无法解析`);
      }
      return finalEvent;
    },
  };
}

function findBoundary(buffer: string): { index: number; length: number } | -1 {
  const lf = buffer.indexOf("\n\n");
  const crlf = buffer.indexOf("\r\n\r\n");
  if (lf === -1 && crlf === -1) return -1;
  if (crlf !== -1 && (lf === -1 || crlf < lf)) return { index: crlf, length: 4 };
  return { index: lf, length: 2 };
}

/* ------------------------------------------------------------------ */
/* output                                                              */
/* ------------------------------------------------------------------ */

export interface SynthesisRequest {
  eventId: string;
  sessionId: string;
  content: string;
  emotion: string;
  type: string;
  intent: string;
}

export class OutputAdapter {
  constructor(private readonly base: string) {}

  async probe(): Promise<boolean> {
    try {
      const res = await request({
        url: `${this.base}/api/health`,
        method: "GET",
        timeoutMs: TIMEOUTS.probe,
      });
      if (res.status < 200 || res.status >= 400) return false;
      try {
        return contractMajorOk(await readJson(res), 1);
      } catch {
        return true;
      }
    } catch {
      return false;
    }
  }

  async synthesize(synth: SynthesisRequest, signal?: AbortSignal): Promise<OutputEvent> {
    const body = JSON.stringify({
      event_id: synth.eventId,
      session_id: synth.sessionId,
      content: synth.content,
      stream: false,
      tags: {
        emotion: synth.emotion,
        type: synth.type,
        intent: synth.intent,
      },
    });

    let response: HttpResponse;
    try {
      response = await request({
        url: `${this.base}/api/v1/outputs`,
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body,
        timeoutMs: TIMEOUTS.outputSynthesis,
        signal,
      });
    } catch (error) {
      throw toUpstreamError("output", "synthesize", error);
    }

    const raw = await readJson(response);
    if (response.status >= 400) {
      throw new UpstreamRejectedError("output", parseUpstreamError(raw));
    }
    return parseOutputEvent(raw);
  }

  audioUrl(audioRef: string | null): string | null {
    return resolveAudioUrl(this.base, audioRef);
  }
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

export async function withTimeout<T>(
  promise: Promise<T>,
  ms: number,
  module: string,
  stage: string,
): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new TimeoutError(module, stage, ms)), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

/** 把上游错误码映射为面向用户的短句；不展示上游原文。 */
export function userFacingError(error: unknown): string {
  if (error instanceof TimeoutError) {
    if (error.module === "omninexus") return "模型响应超时，稍后再试一次。";
    if (error.module === "input") return "输入处理超时，请重试。";
    return "语音合成超时，本条先只显示文字。";
  }
  if (error instanceof UpstreamUnavailableError) {
    if (error.module === "input") return "输入服务未连接，请检查输入层是否已启动。";
    if (error.module === "omninexus") return "模型服务未连接，请检查模型层是否已启动。";
    return "语音服务未连接，本条先只显示文字。";
  }
  if (error instanceof UpstreamRejectedError) {
    switch (error.upstream.code) {
      /* --- 模型 / 厂商（首跑最常见）--- */
      case "NO_PROVIDER_AVAILABLE":
      case "ALL_PROVIDERS_FAILED":
      case "PROVIDER_UNAVAILABLE":
      case "MODEL_UNAVAILABLE":
      case "UNKNOWN_MODEL":
      case "DEFAULT_PROVIDER_REQUIRED":
        return "还没有可用的模型，请先在模型层配置一个厂商密钥（启动器「厂商」页可一键配置）。";
      case "PROVIDER_AUTH":
      case "PROVIDER_TEST_AUTH_FAILED":
        return "模型厂商鉴权失败，请检查密钥是否正确、是否过期。";
      case "PROVIDER_RATE_LIMITED":
        return "模型厂商限流了，稍后再试。";
      case "PROVIDER_TIMEOUT":
      case "PROVIDER_TEST_TIMEOUT":
        return "模型厂商响应超时，稍后再试。";
      case "PROVIDER_TEST_UNREACHABLE":
        return "连不上模型厂商，请检查网络或代理设置。";
      case "PROVIDER_TEST_MODEL_NOT_FOUND":
      case "CUSTOM_MODEL_NOT_FOUND":
        return "厂商不认这个模型名，换一个模型或检查配置。";
      case "PROVIDER_TEST_UNVERIFIED":
        return "这家厂商尚未验证通过，请先在模型层完成一次连接测试。";
      case "PROVIDER_IN_USE":
        return "这个厂商正在被当前会话使用，先切换会话再改。";
      case "SECRET_STORE_ERROR":
        return "模型层的密钥存储出错（可能是密钥格式不对），请检查密钥配置。";
      case "CONFIG_IMPORT_INVALID":
        return "模型层配置导入失败，请检查导入文件格式。";

      /* --- 会话 / 提示词 --- */
      case "SESSION_NOT_FOUND":
        return "这个会话在模型层已不存在，请点「新对话」重新开始。";
      case "PROMPT_NOT_FOUND":
      case "PROMPT_VERSION_NOT_FOUND":
        return "提示词配置不存在，已改用默认人格。";
      case "PROMPT_BUILTIN_PROTECTED":
        return "内置提示词不能删除或改名。";
      case "PROMPT_INVALID":
        return "提示词内容不合规，请修改后再试。";
      case "MESSAGE_NOT_FOUND":
        return "找不到对应消息，可能已被清理。";

      /* --- 输入 / 容量 --- */
      case "INVALID_INPUT":
        return "这条输入格式不对，换一种说法试试。";
      case "UNSUPPORTED_MODALITY":
        return "当前模型不接受这种输入类型（例如纯文本模型收到图片）。";
      case "PAYLOAD_TOO_LARGE":
        return "内容太大了，请压缩或分段发送。";
      case "EVENT_DUPLICATE":
        return "这条消息重复了，已按上一次的结果处理。";

      /* --- 记忆 / 检索（降级项，不阻断对话）--- */
      case "MEMORY_UNAVAILABLE":
      case "MEMORY_TIMEOUT":
      case "MEMORY_BAD_RESPONSE":
        return "记忆模块暂时不可用，本轮不带记忆回答。";
      case "SEARCH_UNAVAILABLE":
      case "SEARCH_NOT_CONFIGURED":
        return "联网检索不可用，本轮只凭模型知识回答。";

      /* --- 中断 --- */
      case "GENERATION_INTERRUPTED":
        return "回答生成到一半中断了，已保留前面的内容。";

      /* --- 语音层（MoodVoice 错误码）--- */
      case "no_ready_provider":
        return "没有可用的语音厂商，本条先只显示文字。";
      case "missing_credentials":
        return "语音厂商缺少密钥，本条先只显示文字。";
      case "content_too_long":
        return "要朗读的文本太长，本条先只显示文字。";
      case "stream_interrupted":
      case "empty_audio":
      case "invalid_response":
        return "语音合成异常，本条先只显示文字。";
      case "provider_error":
      case "http_error":
      case "edge_tts_error":
        return "语音厂商调用失败，本条先只显示文字。";
      case "key_store_unavailable":
        return "语音层的系统凭据库不可用，密钥只在本次会话内有效。";

      /* --- 输入层（小写码，此前全部未映射）--- */
      case "payload_too_large":
        return "内容太大了，超过了输入层的单次上限。请裁剪或压缩后重试。";
      case "unsupported_media":
        return "输入层不支持这种文件格式。图片用 PNG / JPEG / WebP，音频用 WAV / MP3 / M4A。";
      case "invalid_input":
      case "invalid_request":
        return "输入内容不符合要求，请检查后重试。";
      case "unauthorized":
        return "输入层要求鉴权但凭证无效。请检查输入层的 API 令牌配置。";
      case "forbidden_origin":
        return "输入层拒绝了这次请求的来源（域名白名单未通过）。请检查输入层的来源配置。";
      case "privacy_disabled":
        return "输入层的隐私模式已关闭相关能力，本次内容未上传。请到输入层控制台确认隐私设置。";
      case "consent_required":
        return "这次操作需要先获得你的授权（语音/摄像头等），当前未授权，已中止。";
      case "provider_unavailable":
        return "输入层依赖的厂商服务暂时不可用，稍后再试。";
      case "conflict":
        return "输入层状态冲突（可能上一次请求尚未完成），稍后重试。";
      case "not_found":
        return "输入层找不到对应的资源（可能是媒体已过期或被清理）。";

      /* --- 语音层补充（此前部分未映射）--- */
      case "invalid_event":
        return "语音层收到了不合法的事件内容，本条只显示文字。";
      case "unsupported_format":
        return "语音层不支持该音频格式，本条只显示文字。";
      case "unknown_provider":
        return "语音层配置的厂商不存在或已删除，请到语音层控制台重新选择。";
      case "timeout":
        return "语音合成超时，本条先只显示文字。";
      case "cache_write_failed":
      case "cache_error":
        return "语音缓存读写失败（不影响本次内容），本条仍可正常显示文字。";
      case "internal_error":
        return "上游内部错误，稍后再试；若持续出现请查看该模块日志。";

      /* --- 代理 / 开发模式 --- */
      case "origin_not_allowed":
        return "上游拒绝了跨域请求，请通过桌面应用运行（详见排障文档）。";

      default:
        return "上游服务返回了错误，稍后重试。";
    }
  }
  if (error instanceof ContractError) return "上游返回的数据格式异常，已降级显示。";
  return "出了点问题，稍后重试。";
}
