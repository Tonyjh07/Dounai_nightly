"""OmniNexus test suite."""
