# Changelog

## 0.3.4 — 2026-11-11

### Security

- **BYOK 密钥外发 / SSRF**：自定义提供方的「测试连接」「发现模型」不再把已存密钥发往
  请求体指定的 URL。已保存提供方只用已存 Base URL；覆盖 URL 时必须显式提供 `apiKey`。
- **出站策略**：拒绝回环/私网/链路本地/元数据地址，DNS 解析后校验全部记录并把已校验 IP
  pin 到实际连接（防 DNS 重绑）；新增 `EGRESS_BLOCKED`（422）。
  本地模型需显式 `server.allow_private_targets: true`。
- **绑定加固**：非回环绑定且未显式放行时拒绝启动（`server.allow_insecure_bind` /
  `--allow-insecure` / `OMNI_ALLOW_INSECURE_BIND=1`）。
- **请求体上限**：不再只依赖 `Content-Length`；chunked / 无长度请求按实际字节数校验。

### Fixed

- `OmniError.as_dict()` 补齐 `request_id`，与 `X-Request-ID` 一致。
- SSE 兜底错误帧 `retryable` 由 `true` 改为 `false`，与 JSON 路径一致。
- 非流式 `run_json` 重建错误时保留 `retryable`。
- 新增回归测试 32 例（`test_provider_security.py`、`test_hardening.py`）。

## 0.3.3 — 2026-11-07

### Added

- `GET /v1/contract`：只读机读契约端点，含 event / emotion / memory / error 版本、12 类情绪、
  旧别名与不兼容处理策略。
- `GET /v1/healthz` 增加 `service_version`、`contract_version`、`tag_contract`。

### Fixed

- **旧会话兼容**：0.3.1 之前创建、拆分字段为 NULL 且**尚无模型回答**的会话，首次对话自动
  迁移到当前可用默认，`meta.recovered_default=true`；**已有回答的会话保持原模型**。
- 旧会话不可用时，409 的 `message` 说明当前模型与建议目标，`details.suggested` 给出
  `providerKind/providerId/model`，不再只提示“重新选择”。
- `OmniError` 响应体补 `request_id`，与 `X-Request-ID` 一致；错误契约字段齐备。

### Changed

- 文档明确版本语义：`service_version`（包版本）≠ `contract_version`（契约版本）。
- 文档固化错误体字段与 12 类情绪为唯一权威列表。

## 0.3.2 — 2026-11-07

### Fixed

- **Issue #1**：自定义提供方模型数超过 200 时，422 不再只显示
  `Request validation failed.`，`error.message` 直接说明“最多 200 个模型”。
- 设置页新增字段级错误条，展示 `details.fields` 的首条原因；保存失败时 toast 同步显示。
- 「从 /models 拉取」按剩余容量截断，超过 200 的部分不再生成 DOM，并提示未加入数量。
- 模型区域显示 `当前 / 200` 计数；达到上限后禁用“手动添加”。
- 新增边界回归测试：199/200 接受、201/300 返回可读 422。
- 文档补充 `OMNI_DATA_DIR` 必须是最终目录，避免启动器双层嵌套空库。

## 0.3.1 — 2026-11-05

### Fixed

- **默认提供方/模型未作用于新会话**：`orchestrator` 在创建会话前读取
  `/v1/provider-defaults`，并把 `provider_kind/provider_id/model_name` 与 canonical
  `model` 一起持久化；不再被静态 `gateway.default_model` 遮蔽（Dounai 审计）。
- 会话 `model` 与拆分字段统一生成，避免新旧字段不一致。
- 历史会话保持原样、不静默迁移；不可用提供方仍返回 `409 PROVIDER_UNAVAILABLE`。
- 新增回归测试 `test_new_session_uses_provider_defaults_not_gateway_default`。

## 0.3.0 — 2026-11-03 / hotfix 2026-11-05

### Changed

- **Emotion contract v2**：对外只输出 12 类（neutral/joy/excitement/comfort/tenderness/calm/
  sadness/apology/encouragement/surprise/frustration/anger）；旧 `fear→sadness`、
  `confusion→frustration`、`gratitude→joy` 在边界归一。
- `GET /v1/health`、`GET /v1/settings` 增加 `tag_contract`；SSE/JSON 增加
  `X-OmniNexus-Tag-Contract: 2`。
- `metadata.session_id` 兼容回退 + warning；顶层 `session_id` 缺失时 warning 并在
  `meta`/响应头标记 `session_created`。
- `gateway.citations_in_content` 默认 `false`：来源 URL 不再进入 `final.content`，仍通过
  citations 事件与 API 提供。
- 默认模型不可用时优先选择默认厂商的已配置模型，减少“只配一家厂商首跑失败”。
- **修复设置页默认提供方/模型不生效**：新建会话直接持久化 `provider-defaults`，不再被
  `gateway.default_model` 遮蔽；历史会话保持原样、不静默迁移（Dounai 审计 2026-11-05）。
- 版本与 tag `v0.3.0`；新增 `docs/COMPATIBILITY.md` 与发布说明。

## 0.2.0 — 2026-10-30

### Added

- Chatbox 式自定义模型提供方：名称、Base URL、API Key、模型列表、能力、请求头、协议、超时。
- 提供方列表/编辑/删除/启用禁用；默认提供方与默认模型；导入/导出（不含 Key）。
- 三级连接测试（地址、`/models`、最小聊天）+ 可选多模态探测 + 未验证状态。
- API Key 本机 AES-GCM 加密、前端仅掩码、日志/错误/导出不含 Key。
- 自定义模型能力字段与预设，图片输入同提供方内视觉路由/文本降级。
- 历史会话不可用标记 + 手动迁移向导；删除默认/占用提供方保护。
- 系统设置页（`/settings`）与聊天页“提供方 + 模型”双选择器。

### Changed

- 内置厂商保持只读；自定义提供方仅支持 OpenAI-compatible。
- Base URL 严格拼接，不自动补 `/v1`；纯域名仅前端非强制提示。
- 数据库 schema v2（自定义提供方/模型、默认设置、会话 provider 字段）。

## 0.1.0 — 2026-10-24

首个可独立运行的交付版本（任务书 v1.1）。

### Added

- 多厂商模型网关：OpenAI-compatible（OpenAI、DeepSeek、Mistral、xAI、Qwen、Doubao、GLM、
  Moonshot、Qianfan、Spark、Hunyuan、MiniMax、OpenRouter、Ollama、LM Studio、vLLM、llama.cpp）、
  Anthropic、Gemini、Cohere 原生适配器。
- 运行时模型切换、上下文延续、重试、首 Token 超时、进程内限流、模型回退链与已配置模型重路由。
- 多模态能力协商：视觉路由、文本化降级、回退时图片剥离。
- 提示词档案与不可变版本：创建/保存/激活/重置/删除/预览；Jinja2 沙箱变量注入。
- 本地对话存档（SQLite WAL）：会话、消息、引用、导出 JSON/Markdown、删除、Token 预算裁剪。
- 确定性情感/内容类型/意图标签，随 `delta`/`final` 事件下发。
- 可配置联网搜索（Tavily/Brave/SearXNG/DuckDuckGo/自定义），RAG + 引用溯源，查询最小化。
- SSE 契约：`meta`/`route`/`delta`/`final`/`citations`/`warning`/`error` 与心跳。
- 本地零构建 Web 页面：对话、模型/提示词切换、图片、搜索、存档、导出/删除、提示词管理。
- 隐私：密钥仅环境变量、日志脱敏、错误正文不回显、`.env`/data/log 忽略。
- **Reserved**：外部记忆插件接口（默认禁用、健康探测 `unavailable`、契约 v1.0、mock 验证）。
- 文档：架构、API、提示词、厂商、降级、隐私、用户、开发、测试报告、验收对照。
- CI、Dockerfile、docker-compose、MIT License。

### Notes

- 未内置正式人设或测试人格；默认系统提示词为空。
- 外部记忆管线不参与本期交付。
- 不提供密钥/账户（BYOK）。
