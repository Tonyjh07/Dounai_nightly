"""Prompt templates and versioning."""
