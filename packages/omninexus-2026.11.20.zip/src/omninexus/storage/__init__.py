"""Local persistence package."""
