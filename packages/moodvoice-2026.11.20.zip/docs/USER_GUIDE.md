# 用户文档 · 安装、Demo 与 BYOK

本文面向第一次运行 MoodVoice 的使用者。目标：不接其他模块，独立完成
“输入文本 → 输出带情感语音”的完整演示；然后按需接入自己的 TTS 厂商账户。

---

## 1. 运行环境

- Python **3.11+**（推荐 3.12）
- Windows / macOS / Linux
- 首次安装依赖时需要网络
- 使用默认 `edge-tts` 时需要能访问微软在线朗读服务（不需要账号或密钥）
- 若要求文本完全不出本机，请直接使用 `local` 适配器（见 5.7）
- 不想改配置文件时，可以在页面里直接接入任意 TTS API（见 5.8）

检查：

```powershell
python --version
```

如果系统里有多个 Python，建议显式创建虚拟环境，避免依赖装到全局。

---

## 2. 安装

在仓库根目录执行（PowerShell）：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
Copy-Item .env.example .env
```

macOS / Linux：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
cp .env.example .env
```

> 如果 PowerShell 提示“禁止运行脚本”，可以不激活虚拟环境，直接使用
> `.\.venv\Scripts\python.exe -m emotional_tts serve`。

`.env` 已被 `.gitignore` 忽略；不要提交、不要发给他人。

---

## 3. 启动 Demo

```powershell
python -m emotional_tts serve
# 或安装后：
moodvoice serve
```

看到类似输出即成功：

```text
MoodVoice Demo: http://127.0.0.1:8765
只监听本机；按 Ctrl+C 停止。
```

打开浏览器访问 **http://127.0.0.1:8765**。

### 不需要密钥的第一次试听

1. 保留默认文本；
2. 情感标签选“安慰”；
3. 内容类型选“普通文本”；
4. 意图选“回复”；
5. 语音厂商选“自动选择”；
6. 打开“流式播放”，点击“生成情感语音”。

你会看到：

- 音频在合成过程中就开始播放（浏览器支持 MSE 时）；
- “首响”显示从收到事件到收到第一段音频的毫秒数；
- 下方展示实际朗读稿、文本渲染、路由和诊断；
- 默认 `edge` 会返回 `route=ui.voice_reply`，并生成一条本地记录；
- 结果区的“本次文本去向”会显示 `已出网`，提示文本已发往微软在线朗读服务。

### Demo 里值得试的四个场景

| 场景 | 操作 | 预期 |
|---|---|---|
| 情感差异 | 同一段话分别选“安慰 / 开心 / 兴奋” | 语速、音高、音色/风格参数变化；`speed` 与 `tone` 同步变化 |
| 代码不朗读 | 内容类型选“代码”，粘贴一段 Python | 屏幕显示代码块，朗读只说“代码已经显示在屏幕上” |
| 意图路由 | 意图选“工具结果” | 不合成语音，状态为“纯文本路由”，`audio_ref=null` |
| 纯文本降级 | 选一个显示“未配置”的厂商 | 保留完整文本，状态为“纯文本降级”，诊断里能看到失败原因 |

> 默认 `edge-tts` 是**在线**服务：不需要账号，但朗读文本会发往微软的朗读服务。
> UI 的“数据边界”卡片会随厂商切换更新说明，每次结果也会单独显示文本去向和
> `已出网/本机/未发送` 标记。

---

## 4. 命令行 Demo

不启动 Web 也可以跑完整链路：

```powershell
python -m emotional_tts demo "今天辛苦了，先慢慢呼吸一下。" `
  --emotion comfort `
  --type text `
  --intent reply `
  --provider edge `
  --out .data/demo.mp3
```

- 标准输出是完整输出事件 JSON（含 `style`、`render`、`route`、`diagnostics`、`timings`）。
- `--out` 会把缓存音频复制到指定位置；不指定时只写入 `.data/cache/`。
- 不是所有厂商都能匿名运行；`--provider openai` 等需要先完成 BYOK。

---

## 5. BYOK：填写你自己的密钥

### 5.1 三条硬规则

1. 密钥**只**放在本地 `.env` 或系统环境变量里；
2. 不把 `.env`、密钥、账户信息放进仓库、截图、Issue 或聊天；
3. 不把密钥填进 Demo 页面。页面不会读取密钥，服务端也不会通过 API 返回密钥。

复制模板后，只填写你实际会用到的字段：

```powershell
Copy-Item .env.example .env
notepad .env
```

配置完成后重启 `moodvoice serve`，再执行：

```powershell
moodvoice providers
```

该命令只显示“是否就绪 / 缺少哪个环境变量”，不会打印密钥值。

### 5.2 通用变量表

| 厂商 | 环境变量（`.env`） | 非密钥配置 |
|---|---|---|
| edge-tts | 无 | `config/app.yaml → providers.edge.voice` |
| OpenAI TTS | `OPENAI_API_KEY` | `model`、`voice`、`response_format`；可选 `OPENAI_BASE_URL` |
| ElevenLabs | `ELEVENLABS_API_KEY` | `config/app.yaml → providers.elevenlabs.voice_id`、`model_id` |
| Azure Neural TTS | `AZURE_SPEECH_KEY`、`AZURE_SPEECH_REGION` | `voice`、`output_format` |
| MiniMax 海螺 | `MINIMAX_API_KEY`，按账户需要 `MINIMAX_GROUP_ID` | `model`、`voice_id`、`base_url` |
| 本地 TTS | 可选 `LOCAL_TTS_API_KEY` | `LOCAL_TTS_URL`、`format`、`voice` |

### 5.3 OpenAI TTS

1. 登录 <https://platform.openai.com/>，在 API Keys 页面创建项目密钥；
2. 确认项目有 TTS 模型权限和可用额度；
3. 编辑 `.env`：

```dotenv
OPENAI_API_KEY=<your-openai-api-key>
```

4. 默认模型是 `gpt-4o-mini-tts`。它支持自然语言表演指令，情感映射会通过
   `instructions` 传入；`tts-1` / `tts-1-hd` 只支持语速，代码会自动省略
   `instructions`，避免厂商拒绝参数。
5. 可选：如果你使用兼容网关，设置 `OPENAI_BASE_URL=https://你的网关/v1`。
6. 重启服务，在 Demo 中选择 “OpenAI TTS”，或 CLI 加 `--provider openai`。

### 5.4 ElevenLabs

1. 登录 <https://elevenlabs.io/>，在账户设置里创建 API Key；
2. 在 Voices 页面复制目标 Voice ID；
3. 编辑 `.env`：

```dotenv
ELEVENLABS_API_KEY=你的密钥
```

4. 把 Voice ID 填到 `config/app.yaml`（它不是密钥，但仍建议只放本地）：

```yaml
providers:
  elevenlabs:
    voice_id: "你的_voice_id"
```

5. 重启并选择 “ElevenLabs”。
6. 情感映射使用 `stability / similarity_boost / style / speed`，不依赖离散
   `style` 枚举；不同 Voice 对风格强度的响应可能不同，以试听为准。

### 5.5 Azure Neural TTS

1. 在 Azure Portal 创建 Speech 资源；
2. 在 “Keys and Endpoint” 复制 Key 和 Region（例如 `eastasia`）；
3. 编辑 `.env`：

```dotenv
AZURE_SPEECH_KEY=你的密钥
AZURE_SPEECH_REGION=eastasia
```

4. 重启并选择 “Azure Neural TTS”。
5. 默认音色为 `zh-CN-XiaoxiaoNeural`。Azure 的原生情感风格支持范围**因音色而异**；
   如果某风格不被该音色支持，会收到 4xx，诊断中会记录 `style_resolution` 或
   `provider_rejected`，请按根因手册检查映射和音色，而不是盲目改语速。

### 5.6 MiniMax 海螺语音

1. 登录 MiniMax 开放平台，创建 API Key，确认账户信息和音色；
2. 编辑 `.env`：

```dotenv
MINIMAX_API_KEY=你的密钥
MINIMAX_GROUP_ID=你的_group_id
```

3. 在 `config/app.yaml` 确认 `providers.minimax.voice_id` 和 `model`；
4. 中国大陆默认端点为 `https://api.minimax.chat/v1/t2a_v2`；国际站可设置
   `MINIMAX_BASE_URL=https://api.minimax.io/v1/t2a_v2`；
5. 重启并选择 “MiniMax 海螺语音”。
6. 该适配器使用同步接口一次性返回 hex 音频，因此首响通常高于流式厂商；
   这是厂商协议限制，不是适配层故障。

### 5.7 本地部署（完全不出本机）

推荐场景：GPT-SoVITS、CosyVoice、F5-TTS，或你自己的推理服务。

1. 在本地启动一个 HTTP 服务，实现 `docs/PROVIDERS.md` 里的统一契约；
2. `.env`：

```dotenv
LOCAL_TTS_URL=http://127.0.0.1:9880/synthesize
# 如果本地服务开了 Bearer 鉴权：
LOCAL_TTS_API_KEY=
```

3. 在 `config/app.yaml` 确认：

```yaml
providers:
  local:
    format: "wav"   # 必须与本地服务实际返回一致
```

4. 重启，在 Demo 选择 “本地 TTS（HTTP）”。
5. 适配器会把 `emotion / tone / speed / pitch_semitones / volume_db` 原样放进
   `style` 载荷，由本地模型决定如何使用。MoodVoice 不会把文本转发到其他地方。

也可以选择 `edge` 做免密钥演示，但要清楚它是**在线**服务，不是本地推理。

### 5.8 页面内接入：URL + API Key（四种协议）

如果你手上只有某家（或自建网关）的 **Base URL** 和 **API Key**，又不想改
`config/app.yaml`、不想重启服务，用这条路径。它和 5.3–5.7 的 `.env` 方式是并存的：
内置厂商照旧可用，接入的连接会以一个 `api_...` 的厂商 ID 出现在下拉框里。

**操作步骤**

1. 启动 Demo，在“语音厂商”右侧点击 **＋ 接入 API**；
2. 填 **Base URL**（例如 `https://api.openai.com/v1`）和 **API Key**；
3. 协议先保留“自动识别”；点 **探索模型**；
4. 识别成功后，在“模型 / 音色”下拉框里选择实际要用的组合
   （下拉框没有你想要的值时，可在下方“手动填写”输入框补上）；
5. 点 **试听测试**，会用一句固定测试文本真实调用一次厂商，并直接播放返回音频；
6. 填一个**连接名称**，点 **保存连接**。保存后页面会自动切换到该连接；
7. 之后正常“生成情感语音”，结果区的“本次文本去向”会写明是这个连接。

**四种协议各自会发现什么**

| 协议 | Base URL 示例 | 自动探索 | 鉴权头 |
|---|---|---|---|
| OpenAI 兼容 | `https://api.openai.com/v1` | 模型列表；若服务提供 `/audio/voices` 则用它的音色，否则列 OpenAI 常用音色 | `Authorization: Bearer` |
| Azure Speech | `https://<region>.tts.speech.microsoft.com` | 音色 + 每个音色支持的情感风格 | `Ocp-Apim-Subscription-Key` |
| ElevenLabs | `https://api.elevenlabs.io/v1` | 模型 + 账号下的音色 | `xi-api-key` |
| MiniMax | `https://api.minimax.chat/v1/t2a_v2` | 账号下的系统音色（模型用固定列表） | `Authorization: Bearer` |

> 兼容网关（One API、LiteLLM、vLLM-TTS 等）通常选 “OpenAI 兼容” 即可：只要它实现
> 了 `GET /models` 和 `POST /audio/speech`。

**密钥存在哪里**

- 默认写入**操作系统凭据库**：Windows 凭据管理器、macOS Keychain、Linux Secret
  Service；连接名称、URL、模型等元数据写在 `.data/connections.json`，**不含密钥**；
- 系统没有可用凭据库时，页面会显示“本次会话”，密钥只存在于服务进程内存中，
  重启服务后需要重新填写（服务不会把密钥落盘到任何地方）；
- 密钥只在你本机的浏览器 → 本机服务之间传输一次，页面不会写 `localStorage`、
  不会回显、保存后输入框会被清空；日志和 API 响应都不含密钥值。

**安全限制（有意为之）**

- 只接受 `https://`；`http://` 仅允许 `127.0.0.1` / `localhost` / `::1`；
- 想让服务访问局域网里的 TTS（例如自建 GPU 机器），必须显式勾选
  **“允许局域网 HTTP（仅当你信任该服务）”**；
- 拒绝跳转（3xx）、拒绝带用户名密码的 URL、拒绝云主机元数据地址与链路本地地址；
- 公网域名若解析到本机地址会被拒绝（防 DNS rebinding）；内网/局域网地址在未勾选
  “允许局域网 HTTP” 时同样会被拒绝；
- HTTPS 按系统信任链校验，**不支持自签名证书**；局域网自签场景请换成受信任证书，
  或先用本机回环地址。

**修改与删除**

- 再次点“接入 API”可以新增更多连接，每个连接独立保存密钥与默认模型/音色；
- “已保存的 API 连接”里可以随时 **试听**（不改动正式记录）；
- **删除** 会同时移除本地元数据、凭据库条目和已注册的厂商，不可撤销。

> **没有密钥的本地服务**：OpenAI 兼容协议允许本机（`127.0.0.1` / `localhost`）
> 的免密钥服务，例如 LM Studio、vLLM、自建网关。API Key 留空即可保存和试听；
> 这种连接不会发送 `Authorization` 头。远程地址仍然必须填密钥，否则会提示
> “连接未就绪：连接 API Key”。

---

## 6. 厂商切换与降级

### 6.0 情感标签输入

Demo 的情感下拉框已包含 12 个 canonical 标签和 3 个上游兼容标签：

- `fear`（恐惧）→ 悲伤
- `confusion`（困惑）→ 受挫
- `gratitude`（感激）→ 开心

**口径**：规范集是这 12 类；上游的 9 类标签（含上面 3 个）都通过**显式别名**精确命中，
不是"兜底"。9 类以外的值（如 `disgust`）会回退到 `neutral`，并在输出里标
`mapping_hit=false`，同时计入 `/api/health.emotion_mapping.fallbacks`。

API 可直接传 OmniNexus 的 9 类原值，无需组装层先做映射。机器可读的完整清单在
`GET /api/v1/contract`（见 [CONTRACT.md](CONTRACT.md)），消费方不必再读文档猜。

### 6.1 切换

- **Demo**：右上“语音厂商”下拉框，立即生效；
- **API**：`POST /api/v1/outputs?provider=azure`；
- **默认值**：`.env` 的 `EMOTION_TTS_PROVIDER=auto` 或某个厂商 ID；
- **自动模式**：按 `config/app.yaml` 的 `auto_order` 选第一个“已就绪”的厂商。

可用厂商 ID：`edge`、`openai`、`elevenlabs`、`azure`、`minimax`、`local`，
以及你在页面里保存的 API 连接（`api_` 开头的 ID）。API 连接不会进入自动选择
顺序——`auto` 永远只在上面 6 个内置厂商里挑，避免页面外的默认流量被静默改道。

### 6.2 降级规则

- 默认：所选厂商失败 → **纯文本输出**（`degraded=true`，`audio_ref=null`）。
- 可选：显式配置降级链：

```dotenv
EMOTION_TTS_FALLBACK_PROVIDERS=local
```

- 只有写进降级链的厂商才会收到同一段文本；没有显式配置时不会偷偷换厂商。
- 所有尝试记录在 `diagnostics.provider_attempts`，包含厂商、错误码、阶段、
  可重试性和 `first_chunk_ms`。
- 流式播放中，如果已经向浏览器发出音频后才失败，不会把两个厂商的音频拼在一起；
  服务端会关闭流、删除不完整文件，并在记录中标记 `stream_interrupted`。

### 6.3 验证降级

在 Demo 里选择一个显示“未配置”的厂商，点击生成：

- 页面显示“已降级为纯文本”；
- 音频区域不播放；
- “开发诊断”里能看到 `missing_credentials` 和缺少的环境变量名（不含值）；
- 文本、渲染和路由仍正常下发。

---

## 7. 清除本地数据

音频和结构化记录都只在本机。三种清理方式：

1. **Demo**：右上“清除本地数据”；
2. **HTTP API**：

```powershell
# 只清音频
Invoke-RestMethod -Method Delete http://127.0.0.1:8765/api/v1/cache
# 只清结构化记录
Invoke-RestMethod -Method Delete http://127.0.0.1:8765/api/v1/records
# 全清
Invoke-RestMethod -Method Delete http://127.0.0.1:8765/api/v1/user-data
```

3. **CLI**：

```powershell
moodvoice cache info
moodvoice cache clear
moodvoice cache clear --records
```

说明：

- 音频默认保留 168 小时，最多 200 个文件，超出自动清理；
- 结构化记录**不含原文和朗读稿**，只含标签、风格、厂商、延迟、结果；
- 删除 `.data/` 目录可彻底重置，但请先停止服务。

---

## 8. 常见问题

| 现象 | 可能原因 | 处理 |
|---|---|---|
| 页面显示“本地服务未连接” | 服务未启动或端口不对 | 确认 `moodvoice serve` 正在运行，访问控制台打印的地址 |
| 选了 OpenAI 却“纯文本降级” | 没有 `OPENAI_API_KEY` / 额度不足 / 网络 | `moodvoice providers`；检查 `.env` 是否在仓库根目录；重启 |
| ElevenLabs 401 或 404 | Key 错误或 Voice ID 不存在 | 重新复制 Voice ID 到 `config/app.yaml`；确认账号权限 |
| Azure 返回 400 | 该音色不支持所选风格，或 region 错 | 换支持该风格的音色；用 `moodvoice diagnose --emotion ... --provider azure` 查看实际请求参数 |
| MiniMax 提示 GroupId | 账户需要 GroupId | 补 `MINIMAX_GROUP_ID`，或改用国际站端点 |
| 代理/Vite 页面访问返回 403 `origin_not_allowed` | 页面 Origin 不在白名单 | 在 `.env` 配置实际页面 Origin，例如 `EMOTION_TTS_ALLOWED_ORIGINS=http://localhost:1420`；开发期可显式使用 `http://localhost:*`（仅本机） |
| 上游传入 `session_id` 不是 UUID 或被省略 | 旧版本强制 UUID | 已兼容：非 UUID 原样接受，缺失时由 `event_id` 派生，返回 `diagnostics.session.source` |
| 本地服务 `format_mismatch` | 返回音频格式与 `providers.local.format` 不一致 | 让两者一致（WAV/MP3），不要只改文件后缀 |
| 接入 API 时“探索失败 / 401” | Key 错、无权限，或 URL 少了 `/v1` | 用 curl 直接请求 `GET <Base URL>/models` 验证；确认协议选对了 |
| 接入 API 时“该地址没有预期的 API 端点” | Base URL 填成了控制台地址或漏了版本前缀 | 参考 5.8 表格里的示例路径 |
| 接入 API 时“本次会话”而不是“系统凭据库” | 系统没有可用凭据库（如精简容器、无桌面会话） | 不影响使用，但重启后要重填密钥；也可安装 `keyring` 对应的系统后端 |
| 试听成功，正式生成却失败 | 正式生成会带上情感风格参数，某模型不接受 | 换支持该参数的模型，或用 `moodvoice diagnose` 看实际请求体 |
| 局域网 TTS 用 HTTP 被拒 | 默认只允许本机 HTTP | 勾选“允许局域网 HTTP（仅当你信任该服务）” |
| 有文字没声音 | 意图是 `tool`/`linkage`，或厂商失败 | 看 `route.synthesize` 与 `degraded`；切换意图/厂商 |
| 浏览器无法流式播放 | 浏览器不支持该 MIME 的 MSE | 会自动退化为整段播放；仍可下载音频；首响指标在服务端有效 |
| 端口被占用 | 8765 已被其他程序使用 | `moodvoice serve --port 8787`，同时访问新地址 |
| 想从局域网访问 | 默认只监听 127.0.0.1 | 自行加反向代理鉴权；设置 `EMOTION_TTS_HOST=0.0.0.0`、端口和 `EMOTION_TTS_ALLOWED_ORIGINS`；**不要裸奔到公网** |
| 消费方问“支持哪些情绪/错误码” | 不想读文档 | 直接 `GET /api/v1/contract`；响应头 `X-MoodVoice-Contract-Version` 可低成本探测漂移 |

### 端口/地址覆盖

```powershell
moodvoice serve --host 127.0.0.1 --port 8787
```

`.env` 也支持：

```dotenv
EMOTION_TTS_HOST=127.0.0.1
EMOTION_TTS_PORT=8765
```

---

## 9. 安全清单

- [ ] `.env` 在 `.gitignore` 中，且没有被 `git add -f`
- [ ] 密钥只在自己的机器上，未出现在 Demo、日志、Issue、截图里
- [ ] 用页面接入的 API 连接，密钥确实进了系统凭据库（页面显示“系统凭据库”）；
      如果显示“本次会话”，确认这是你接受的临时状态
- [ ] 只为确实需要的连接勾选“允许局域网 HTTP”
- [ ] 使用 `moodvoice providers` 验证，而不是在终端 `echo` 密钥
- [ ] 默认只监听 `127.0.0.1`
- [ ] 不需要语料留存时，定期“清除本地数据”
- [ ] 若切换 `edge`，已告知最终用户文本会离开本机
- [ ] 若部署到服务器，已加鉴权、TLS、访问控制，并重新评估厂商合规

更多细节：[PRIVACY.md](PRIVACY.md)。
